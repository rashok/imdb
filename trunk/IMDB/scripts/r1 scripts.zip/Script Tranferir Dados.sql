
INSERT INTO labbd11..director(name, addition) SELECT DISTINCT directorsmovies.dname, directorsmovies.addition FROM disciplinabd..directorsmovies

INSERT INTO labbd11..movie(title, year) SELECT movies.title, CASE WHEN IsNumeric(movies.mvyear+ '.0e0') <> 1  THEN NULL ELSE CAST (movies.mvyear AS INT) END FROM disciplinabd..movies

INSERT INTO labbd11..movie(id, title, year) SELECT DISTINCT CASE WHEN IsNumeric(movies.movieid+ '.0e0') <> 1  THEN NULL ELSE CAST (movies.movieid AS INT) END , movies.title, CASE WHEN IsNumeric(movies.mvyear+ '.0e0') <> 1  THEN NULL ELSE CAST (movies.mvyear AS INT) END FROM disciplinabd..movies

INSERT INTO labbd11..actor(id, name, sex) SELECT DISTINCT CASE WHEN IsNumeric(movies.actorid+ '.0e0') <> 1  THEN NULL ELSE CAST (movies.actor	id AS INT) END , movies.actorname, movies.sex FROM disciplinabd..movies


SELECT * FROM teste

SELECT TOP 1000 * FROM director

SELECT TOP 1000 * FROM movie

SELECT TOP 1000 languages FROM movies

DELETE FROM movie
DELETE FROM director

CREATE FUNCTION dbo.Split (@sep char(1), @s varchar(512))
RETURNS table
AS
RETURN (
    WITH Pieces(pn, start, stop) AS (
      SELECT 1, 1, CHARINDEX(@sep, @s)
      UNION ALL
      SELECT pn + 1, stop + 1, CHARINDEX(@sep, @s, stop + 1)
      FROM Pieces
      WHERE stop > 0
    )
    SELECT pn,
      SUBSTRING(@s, start, CASE WHEN stop > 0 THEN stop-start ELSE 512 END) AS s
    FROM Pieces
  )

SELECT s FROM dbo.Split(' ', 'I hate bunnies')

INSERT TOP(10000) INTO labbd11..language(language) SELECT DISTINCT s.s FROM disciplinabd..movies m CROSS APPLY dbo.Split(';', m.languages) S
  
SELECT TOP 1000 disciplinabd..movies.languages FROM disciplinabd..movies

SELECT * FROM language

SELECT TOP (1000) * FROM disciplinabd..directorsmovies

SELECT TOP (1000) * FROM disciplinabd..movies

SELECT TOP (1000) * FROM movie


SELECT * FROM disciplinabd..directorsmovies WHERE movieid = 210469

SELECT * FROM disciplinabd..movies WHERE movieid = '210469'






